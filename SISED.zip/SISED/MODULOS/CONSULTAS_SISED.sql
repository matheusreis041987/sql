-- empregados que ganham mais que 1000
select * from emp where sal > 1000;

-- empregados que ganham mais que 1000 e s�o do dpto 1;
select * from emp where sal > 1000 and  dn = 1;

-- empregados que ganham mais que 2000 e s�o do dpto de ADM
select * from emp where sal > 2000 and dn = (select dn from depto where nome like '%adm%');

-- empregados que tem "RI" no seu nome
select * from emp where enome like '%ri%';
select * from emp where enome like '%i_o%';
select * from emp where enome like '%m_t%';

-- nome e sal�rio dos empregados que ganham mais de 1000
select enome as NOME, sal as SALARIO from emp where sal > 1000 order by sal desc; 

-- nome e telefones dos empregados
select  enome AS NOME, tel as TELEFONE from emp as e join tele as p on e.en = p.en;

-- nome e telefones dos empregados(todos)
select  enome AS NOME, tel as TELEFONE from emp as e left join tele as p on e.en = p.en; -- 0 comando left join faz a jun��o mesmo dos campos que ser�o nulos no lado esquerdo

-- listar os empregados que n�o tem telefone;
select * from emp where en not in (select en from tele); -- comando not in 
 

