/* ---------------------------ENUNCIADO--------------------------------------------

PUC-Rio Departamento de Inform�tica 
Prof Rubens 

   SISTEMA EMPREGADOS  (VERSAO SISED)
Enunciado:  Desenvolver um BD Relacional para atender o seguinte minimundo:

"Um empresa tem departamentos e empregados. Cada empregado TRABALHA obrigatoriamente em um �nico departamento. Os empregados tem matricula, nome, sal�rio e 
v�rios (0 ou mais) telefones  como dados relevantes. Sal�rios  devem ser entre 500 e 5000 e o salario default eh 1000 (r1). 
Os departamentos tem c�digo, nome e um telefone como dados relevantes. 
Cada depto tem um chefe que deve ganhar mais que seus subordinados (r2)

Exemplos de Consultas e Transacoes:

Consultas:
 Escrever consultas em SQL:
1-- EMPREGADOS QUE GANHAM MAIS QUE 1000, ORDENADOS POR num do depto 
Resp.: select * from  emp  where sal > 1000 order by dn
2�- NUM dos EMPREGADOS QUE SAO CHEFES
Resp.: select chf from depto ; 
3-- DADOS dos CHEFES DE DEPTOS;
Resp.:  select * from emp where en in(select chf from depto) ;

Fazer consultas mais adiantadas ao BD.
 Escrever consultas em SQL:
1-- EMPREGADOS QUE GANHAM MAIS QUE 1/2 SAL DE SEU CHEFE, ORDENADOS POR DN
Resp.: select * from  emp  e where sal > (select sal from  emp c where 
2�- CHEFES E EMPREGADOS CHEFIADOS QUE GANHAM PELO MENOS 50% DO SEU SAL IGUAL, ORDENADOS POR CHEFE
3-- EMPREGADOS QUE NAO TRABALHAM NO MESMO DEPTO DO CHEFE
4-- EMPREGADOS QUE SAO CHEFES
5-- EN E ENOME DOS CHEFES E OS NOMES DOS CHEFIADOS CUJO NOME CONTENHAM 'RI'
6-- DADOS DE TODOS OS DEPTOS E DE SEUS EMPS ORDENADOS POR DEPTO.DN


GRUPOS VIEWS E INDICES
1� GRUPANDO POR DEPTO OBTER O MAIOR E MENOR SALARIO DO DEPTO
2-- CRIAR UMA VIEW COM TODOS OS DADOS DE CHEFE E NOME DE SEUS CHEFIADOS ORDENADOS PELO EN DO CHEFE
3-- CRIAR UM INDICE DE SALARIO PARA ACESSO A TABELA DE EMP POR VALOR DE SALARIO 
4--CRIAR UMA �VIEW MATERIALIZADA�  SUPV2 QUE GUARDA POR CHEFE O NOME DO CHEFE E O TOTAL DE SALARIO DOS EMPREGADOS CHEFIADOS.

Transacoes:
--DEPOIS ...

�



Organize seu sistema :  

APP
  Mantenha o Sqlite3 e Sqlitespy e outros se precisar na pasta APP
SISED
  DADOS
    Mantennha o BD e os dados emp.txt tele.txt  e depto.txt
    Grave os relatorios  na pasta DADOS\SAIDA
  DOC
    Mantenha este enunciado em DOC
    Mantenha  em doc  os Esquemas Conceitual, Logico e Fisico
  MODULOS
    Mantenha seus arquivos sql  e outros modulos


Zipe apenas o seu SISED no final e se solicitado mande-o zipado para o professor
*/

--------------------------------------------------------------------------------

-- ---------------------TRABALHO SISED------------------------------------------

-- Escrever consultas em SQL:
 
-- 1-- EMPREGADOS QUE GANHAM MAIS QUE 1000, ORDENADOS POR num do depto 
select * from  emp  where sal > 1000 order by dn;

-- 2�- NUM dos EMPREGADOS QUE SAO CHEFES
select chf from depto ; 

-- 3-- DADOS dos CHEFES DE DEPTOS;
select * from emp where en in(select chf from depto) ;

-------------------CONSULTAS AVAN�ADAS DE BD-----------------------------------

-- 1-- EMPREGADOS QUE GANHAM MAIS QUE 1/2 SAL DE SEU CHEFE, ORDENADOS POR DN

select * from emp where en not in (select chf from depto) and 
sal > 0.5 * (select sal from emp where en in(select chf from depto));

-- 2�- CHEFES E EMPREGADOS CHEFIADOS QUE GANHAM PELO MENOS 50% DO SEU SAL IGUAL, ORDENADOS POR CHEFE

select en, enome, sal, emp.dn, nome as nome_dpto, tel, chf  from emp join depto where emp.dn = depto.dn and
sal > 0.5 * (select sal from emp where en in(select chf from depto)) order by chf;

-- 3-- EMPREGADOS QUE NAO TRABALHAM NO MESMO DEPTO DO CHEFE

-- solu��o errada. buscar correta
select * from emp_dpto where (select en from emp_dpto where dn not in (select chf from depto)) = (select en from emp_dpto where dn in (select chf from depto))


-- 4-- EMPREGADOS QUE SAO CHEFES

select * from emp_dpto where en in (select chf from depto);

-- 5-- EN E ENOME DOS CHEFES E OS NOMES DOS CHEFIADOS CUJO NOME CONTENHAM 'RI'

select en, enome from emp where en in (select chf from depto); 
select enome from emp where en not in (select chf from depto) and enome like '%RI%';

-- 6-- DADOS DE TODOS OS DEPTOS E DE SEUS EMPS ORDENADOS POR DEPTO.DN

select * from emp join depto using (dn) order by depto.dn

-------------------GRUPO DE VIEWS E INDICES-----------------------------------

-- 1� GRUPANDO POR DEPTO OBTER O MAIOR E MENOR SALARIO DO DEPTO
create view CONSLIDADO_SAL_DEPTO as select nome_dpto, sum(sal) as salario_por_depto from emp_dpto 
group by nome_dpto  order by salario_por_depto desc;

select * from emp_dpto where sal = (select max(sal) from emp_dpto); -- maior salario
select * from emp_dpto where sal = (select min(sal) from emp_dpto); -- menor salario

-- 2-- CRIAR UMA VIEW COM TODOS OS DADOS DE CHEFE E NOME DE SEUS CHEFIADOS ORDENADOS PELO EN DO CHEFE

create view DADOS_CHEFES as select emp_dpto.* from emp_dpto where en in (select chf from depto);

create view CHEFES_X_CHEFIADOS as select dados_chefes.*, emp.enome as CHEFIADO from dados_chefes join emp order by en;


-- 3-- CRIAR UM INDICE DE SALARIO PARA ACESSO A TABELA DE EMP POR VALOR DE SALARIO

create index salario on emp(sal, enome); 

/* 4--CRIAR UMA �VIEW MATERIALIZADA�  SUPV2 QUE GUARDA POR CHEFE O NOME DO CHEFE E O 
 TOTAL DE SALARIO DOS EMPREGADOS CHEFIADOS.*/
 
 create view SUPV2 as select dados_chefes.enome, dados_chefes.nome_dpto, emp.sal 
 from dados_chefes join emp group by dados_chefes.enome ;

 
