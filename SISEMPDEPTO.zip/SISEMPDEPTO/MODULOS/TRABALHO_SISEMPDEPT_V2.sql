--**************************SISDEPARTAMEMNTO*******************************
--*************************************************************************


-- ********CONSULTAS MAIS SIMPLES******************************************

-- 1)  EMPREGADOS QUE GANHAM MAIS QUE 1000, ORDENADOS POR num do depto

select * from emp where sal > 1000 order by dn

-- 2) NUM dos EMPREGADOS QUE SAO CHEFES

select chf from depto

-- 3) DADOS dos CHEFES DE DEPTOS

select * from emp where en in(select chf from depto) ;

--**********CONSULTAS MAIS AVANÇADAS***************************************

-- 1) EMPREGADOS QUE GANHAM MAIS QUE 1/2 SAL DE SEU CHEFE, ORDENADOS POR DN

 select * from emp e where sal > (select sal from emp c where)

-- 2) CHEFES E EMPREGADOS CHEFIADOS QUE GANHAM PELO MENOS 50% DO SEU SAL IGUAL, ORDENADOS POR CHEFE

select a.en, a.enome, a.tele, a.sal, a.dn, a.sexo, group_concat(b.enome) as Chefiados from 
(select * from emp where sup in (select chf from depto)) as a join (select * from emp where sup not in (select chf from depto)) as b 
where a.sal > (select avg(emp.sal) from emp where sup in (select chf from depto))
group by a.en order by a.en;

-- 3) EMPREGADOS QUE NAO TRABALHAM NO MESMO DEPTO DO CHEFE

select * from (select * from emp where sup not in (select chf from depto)) where dn  not in (select dn from depto) 

-- 4) EMPREGADOS QUE SAO CHEFES

select * from emp where sup in (select chf from depto);

-- 5) CRIAR UMA VIEW COM TODOS OS DADOS DE CHEFE E NOME DE SEUS CHEFIADOS ORDENADOS PELO EN DO CHEFE

create view Chefes_e_Chefiados as
select a.en, a.enome, a.tele, a.sal, a.dn, a.sexo, group_concat(b.enome) as Chefiados from 
(select * from emp where sup in (select chf from depto)) as a join (select * from emp where sup not in (select chf from depto)) as b group by a.en order by a.en;

-- 6) EN E ENOME DOS CHEFES E OS NOMES DOS CHEFIADOS CUJO NOME COMECAM POR ‘ZE’

--- ps. aqui fica  faltando Jose porque ele não está trabalhando no departamento em que ele chefia.
select * from emp 
   join depto on (Emp.dep = depto.dn)
   where (depto.chf = Emp.En) or enome like "r%";

-- 7) DADOS DE TODOS OS DEPTOS E DE SEUS EMPS ORDENADOS POR DEPTO.DN

select * from depto 
  join Emp on(Emp.dep = depto.dn)
  order by depto.dn;

-- 8) CRIAR UM INDICE DE SALARIO PARA ACESSO A TABELA DE EMP POR VALOR DE SALARIO 

create index indice_salario on emp (sal);

-- 9) GRUPANDO POR DEPTO OBTER O MAIOR E MENOR SALARIO DO DEPTO

select dn, min(sal) as menorSalario, max(sal) as maiorSalario from emp group by dn

-- 10) CRIAR UMA “VIEW MATERIALIZADA” SUPV2 QUE GUARDA POR CHEFE O NOME DO CHEFE E O TOTAL DE SALARIO DOS EMPREGADOS CHEFIADOS.

CREATE MATERIALIZED VIEW SUPV2 as
select * from (select * from emp where sup in (select chf from depto)) as a 
join (select sum(sal) as salario_empregado from emp where sup not in (select chf from depto)) as b group by en ;