-- DELETA TUDO DA TAB TADEGA
DELETE FROM TADEGA;
-- CARREGA TUDO
INSERT INTO TADEGA VALUES
(2,'Chardonnay','Buena Vista',1997,1,1999,0),
(3,'Chardonnay','Geyser Peak',1997,5,1999,0),
(6,'Chardonnay','Simi',1996,4,1998,0),
(12,'Joh. Riesling','Jekel',1998,1,1999,0),
(21,'Fume Blanc','Ch. St. Jean',1997,4,1999,0),
(22,'Fume Blanc','Robt. Mondavi',1996,2,1998,0),
(30,'Gewurztraminer','Ch. St. Jean',1998,3,1999,0),
(43,'Cab. Sauvignon','Windsor',1991,12,2000,0),
(45,'Cab. Sauvignon','Geyser Peak',1994,12,2002,0),
(48,'Cab. Sauvignon','Robt. Mondavi',1993,12,2004,0),
(50,'Pinot Noir','Gary Farrell',1996,3,1999,0),
(51,'Pinot Noir','Fetzer',1993,3,2000,0),
(52,'Pinot Noir','Dehlinger',1995,2,1998,0),
(58,'Merlot','Clos du Bois',1994,9,2000,0),
(59,'Merlot','Buena Vista',2000,6,2001,0)
);
UPDATE Tadega SET preco=
     CASE WHEN ano<1992 THEN 350 
          WHEN ano=1997 THEN 150
          ELSE 30+(engarraf-ano)*10 
     END;