drop table if exists Tadega;
create table Tadega  (
	num 	integer      primary key,
	vinho 	text,
	produtor	text,
         	ano	integer,
        	garrafas	integer,
       	engarraf	integer,
      	PRECO integer);

