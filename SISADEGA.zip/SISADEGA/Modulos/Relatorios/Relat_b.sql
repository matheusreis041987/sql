--
-- RODANDO NO DOS EXECUTE .read Modulos\\relat_b.sql (ESTE MODULO)
--
.print "/*------------------------------------------------------------------*/"
.print "/*        b) Lista dos vinhos Pinot Noir colhidos apos 1994             */"
.print "/*------------------------------------------------------------------*/" 
.mode table
SELECT * FROM TADEGA WHERE VINHO='Pinot Noir' AND ANO>1994;