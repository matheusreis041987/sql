--
-- RODANDO NO DOS EXECUTE .read Modulos\\relat_c.sql (ESTE MODULO)
--
.print "/*--------------------------------------------------------------------------------------------------------------------*/"
.print "/*            c) Num, uva, produtor e garrafas dos Vinhos engarrafados pelo menos 2 anos depois da colheita --*/"
.print "/*--------------------------------------------------------------------------------------------------------------------*/" 
.mode table
SELECT NUM, VINHO, PRODUTOR, GARRAFAS FROM TADEGA WHERE (ENGARRAF - ANO) >= 2;