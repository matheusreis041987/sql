--
-- RODANDO NO DOS EXECUTE .read Modulos\\relatorios\\relat_a.sql
--
.print "/*--------------------------------------------------------------------*/"
.print "/*--------------a) Lista dos vinhos com seus precos------**------*/"
.print "/*--------------------------------------------------------------------*/" 
.mode table
SELECT * FROM TADEGA;