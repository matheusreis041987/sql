--
-- RODANDO NO DOS EXECUTE .read Modulos\\transacoes\\transacao_j.sql (ESTE MODULO)
--
.print "/*---------------------------------------------------------------------------*/"
.print "/*        j) Excluir vinhos com estoque zero--------------------------------*/"
.print "/*---------------------------------------------------------------------------*/" 
.print " Situacao atual "
.mode table
.read modulos\\relatorios\\relat_a.sql
-- 
DELETE FROM TADEGA WHERE GARRAFAS = 0;
.print
.print " Situacao apos exclusao de vinhos com estoque zero"
.read modulos\\relatorios\\relat_a.sql


