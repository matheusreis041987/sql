-- ************** EXERC�CIO EM GRUPO - SISTEMA ADEGA  (SISADEGA0)*******************

 
-- a) Lista dos vinhos com seus pre��os
create view a as Select vinho, produtor, preco from tadega;

-- b) Lista dos vinhos Pinot Noir colhidos ap�s 1994 
create view b as select * from tadega where ano > 1994 and vinho like '%pinot Noir%';

-- c) Num, uva, produtor e garrafas dos Vinhos engarrafados pelo menos 2 anos depois da colheita
create view c as select num, vinho, ano, produtor, engarraf from tadega where (engarraf - ano)>=2;

-- d) Vinhos com pre��o em torno da media +- 20 reais 
create view d as select * from tadega where preco between (select avg(preco) from tadega) - 20 and (select avg(preco) from tadega) +20;

--e) Vinhos com o menor pre��o
  select * from tadega where preco = (select min(preco) from tadega);
 
-- f) Quantas garrafas existem de Pinot Noir
  select sum(garrafas) as quant_garrafas_PinorNoir from tadega where vinho like '%pinot Noir%';
 
-- g) Lista dos vinhos mais baratos (abaixo da media de pre��o)
 select * from tadega where preco < (select avg(preco) from tadega);
 
-- h) Lista de vinhos mais caros que os vinhos Pinot Noir
 select * from tadega where preco >  (select max(preco) from tadega where vinho like '%pinot Noir%');
 
-- i) Total em R$ na adega e media de pre��o de uma garrafa
 select sum(garrafas * preco) as Total_Adega from tadega;
 select (sum(garrafas * preco) / sum(garrafas)) as preco_medio_garraf from tadega;
 
 -- outras pesquisas
 select sum(preco) as preco from tadega;
 select sum(garrafas) as soma_garrafa from tadega;
 select avg(preco) as m�dia from tadega;
 select min(preco) as preco_min from tadega;
 select max(preco) as preco_maximo from tadega;
 select count(vinho) as quant_vinhos from Tadega; -- contar� a quantidade de linhas
 select count(distinct vinho) as quant_vinhos from Tadega; -- contar� a quantidade de vinhos sem contar os repetidos
select DISTINCT vinho from tadega;


 select (sum(preco) * count(garrafas)) as total_Chardonnay  from tadega where vinho like 'Chardon%';
  
 
 select (sum(preco) * count (garrafas)) as total_PinotNoir from tadega where vinho like 'pinot%';
 
 
pragma index_list(Tadega);

select * from sqlite_master;


