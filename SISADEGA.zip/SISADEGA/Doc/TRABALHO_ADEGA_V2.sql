-- ************** EXERC�CIO EM GRUPO - SISTEMA ADEGA  (SISADEGA0)*******************

-- a) Lista dos vinhos com seus pre��os
Select vinho, produtor, preco from tadega;

-- b) Lista dos vinhos Pinot Noir colhidos ap�s 1994 
select * from tadega where vinho like '%pinot Noir%' and ano > 1994;

-- c) Num, uva, produtor e garrafas dos Vinhos engarrafados pelo menos 2 anos depois da colheita
select * from tadega where (engarraf - ano)>=2;

-- d) Vinhos com pre��o em torno da media +- 20 reais 
select * from tadega where preco between (select avg(preco) from tadega) - 20 and (select avg(preco) from tadega) +20;

 --e) Vinhos com o menor pre��o
select * from tadega where preco = (select min(preco) from tadega);
 
 -- f) Quantas garrafas existem de Pinot Noir
select sum(garrafas) as quant_garrafas_PinorNoir from tadega where vinho like '%pinot Noir%';
 
 -- g) Lista dos vinhos mais baratos (abaixo da media de pre��o)
select * from tadega where preco < (select avg(preco) from tadega);
 
 -- h) Lista de vinhos mais caros que os vinhos Pinot Noir
select * from tadega where preco >  (select max(preco) from tadega where vinho like '%pinot Noir%');
 
 -- i) Total em R$ na adega e media de pre��o de uma garrafa
select "R$ " || sum(garrafas * preco) as Total_Adega, "R$ " || (sum(garrafas * preco) / sum(garrafas))  as Preco_Medio from tadega;

 -- j) Excluir vinhos com estoque zero
 /*delete from tadega where garrafas = 0;*/
 
 create trigger excluirVinho after update on tadega 
 begin
 delete from tadega where garrafas = 0;
 end;
 
 /*para teste*/
 insert into tadega values (60, 'teste', 'teste', 1990, 1, 2009, 0);
 update tadega set garrafas = 0 where vinho = 'teste';
 
 -- k) Atualizar o estoque de vinhos somando 3 para os que tem menos que 5 garrafas 
 /*update tadega set garrafas = (garrafas + 3) where garrafas < 5 and garrafas > 0;*/
 
 create trigger atualizarEstoque after update on tadega
 begin
 update tadega set garrafas = (garrafas + 3) where garrafas < 5 and garrafas > 0;
 end;
 

 --l) Inserir novos vinhos por exemplo:   5 garrafas tipo Merlot da produtora Aurora colhido em 2009 e engarrafado em 2011 
   insert into tadega values (4, 'Merlot', 'Aurora', 2009, 5, 2011, 0);
 
-- m)  Mudar a regra de pre�os para "Caso o ano seja menor que 1997 o pre�o eh 200 caso o ano seja 1997 o pre�o eh 150 do contrario o pre�o eh 40+20*(engarraf-ano)"
	UPDATE Tadega SET preco=
     CASE WHEN ano<1997 THEN 200
     WHEN ano=1997 THEN 150
          ELSE 40+20*(engarraf-ano)
     END;

 
 
 



