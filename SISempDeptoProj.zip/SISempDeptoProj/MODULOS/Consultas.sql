/*
Exemplos de Consultas  NO sistema EmpDeptoProj:

Salario do EN=1 e dados dos emps que ganham mais que ele
Dados de emps  que ganham>10000 incluindo seu tel de trabalho
Emps com telefone igual ao do depto onde trabalham
Numero, nome de depto e seus emps de maior salario 
Por depto os emps c/ sal < que a metade do maior sal do dept
*/
--
--PRAGMA foreign_keys=1;
--
--Salario do EN=1 e dados dos emps que ganham mais que ele
SELECT (SELECT SAL FROM EMP WHERE EN='E02') SAL1, * FROM EMP WHERE SAL>SAL1; --(SELECT SAL FROM EMP WHERE EN='E02');

--Dados de emps  que ganham>10000 incluindo seu tel de trabalho
select e.*,d.teld from emp e join depto d using(dn) where sal>10000;

--Emps com telefone igual ao do depto onde trabalham
select e.*,d.teld from emp e join depto d using(dn) where tele=teld;

--Numero, nome de depto e seus emps de maior salario 
select e.dn,(select dnome from depto where dn=e.dn) dept,e.*,max(sal) mosal from emp e   group by dn;
-- ou
select d.dn,d.dnome,e.*,max(sal) from depto d join  emp e  using (dn) group by dn;

-- Por depto os emps c/ sal < que a metade do maior sal do seu dept
select e.dn, (select max(sal) from emp where dn=e.dn)/2 msal2, e.en, e.enome, e.sal
  from emp e where e.sal < msal2;
--
-- outras consultas

-- EMPS QUE NAO PARTICIPAM DE PROJ
SELECT * FROM EMP WHERE EN NOT IN (SELECT EN FROM PARTIC) ORDER BY DN;
-- PARTICIPACOES ERRADAS FORA DO SEU DEPTO
SELECT E.DN,E.ENOME, P.DN,P.PNOME FROM PARTIC PP JOIN EMP E USING(EN) JOIN PROJ P USING(PN) WHERE E.DN<>P.DN ;
-- QUEM GANHA MAIS POR DEPTO
SELECT * FROM EMP E WHERE SAL =(SELECT MAX(SAL) FROM EMP WHERE DN=E.DN) ORDER BY DN;
-- QUAIS SAO OS CHEFES 
SELECT EN,ENOME,SAL,E.DN FROM EMP E WHERE EN=(SELECT CHF FROM DEPTO WHERE DN=E.DN);
-- QUE EMPS TEM CHEFES DE OUTRO  DEPTO
SELECT *,(SELECT DN FROM EMP WHERE EN=CHF) AS DEPTCHF,
        (SELECT DNOME FROM DEPTO WHERE DN=(SELECT DN FROM EMP WHERE EN=CHF)) AS DCHFNOME
FROM EMP E JOIN DEPTO D USING(DN) WHERE E.DN <>DEPTCHF;

--
-- TENTANDO "CRIAR" DADOS PARA A TABELA PARTIC 
--

PRAGMA FOREIGN_KEYS=OFF ; 
-- 
-- "CRIANDO" DADOS P AS TABELAS
--
-- PARA CARREGAR PARTIC com dados aleatorios REPETIR O DELETE E INSERT ABAIXO ATE  A RESTRICAO unique PERMITIR...
-- 
/* DELETE FROM PARTIC;
INSERT INTO PARTIC(EN,PN,NH)  
   SELECT DISTINCT ABS(RANDOM())%30 +1,  ABS(RANDOM())%7 +1 , ABS(RANDOM())%21 +5 FROM EMP ORDER BY 1,2; 
*/
--
-- outras CONSULTAS PARA TESTAR OS DADOS
--
-- DEPTOS, SEUS EMPS, SEUS PROJS (ESSES EN SO PODEM TER PAR EM PARTIC COM ESSES PN)
--
SELECT E.DN,
         GROUP_CONCAT(E.EN,' = ') EMPS ,
        (SELECT  GROUP_CONCAT(P.PN,'/ ') FROM PROJ P WHERE p.dn=E.DN GROUP BY p.dn ) PROJS_DESSE_DN 
      FROM EMP E GROUP BY E.DN   

-- EMPS E SEUS CHEFES (NUM DO CHF)

SELECT E.*, (SELECT CHF FROM DEPTO WHERE DN=E.DN) NUMCHF from emp E order by E.EN;  
--
-- EMPS E SUAS PARTIC IPACAO EM PROJ Q DEVEM SER DO SEU DEPTO (CORRIGIR SE NAO FOREM )
--
SELECT E.*,' = ', PP.*,' = ', P.*,' = ',E.DN DEP_EMP
  FROM  EMP  E 
     JOIN PARTIC PP USING(EN) 
     JOIN PROJ P USING (PN)    ORDER BY 1   ;
--
-- EMPS E SUAS PARTIC 
--
SELECT E.*,' / ',D.*, ' / ',PP.*,' / ',P.*  FROM EMP E JOIN DEPTO D USING(DN)
                                                     JOIN PARTIC PP USING(EN)
                                                 JOIN PROJ P USING(PN)  WHERE D.DN != P.DN ORDER BY 1;

-- POR PROJ CHECAR ERROS DE PARTICIPANTES
--
SELECT P.PN, PP.EN PARTICIPANTE,PP.HORAS,  E.DN DEPTO_DELE, CASE WHEN P.DN<>E.DN THEN 'ERRO' ELSE 'OK' END CHEQUE
                                FROM EMP E JOIN DEPTO D USING(DN)
                                          JOIN PARTIC PP USING(EN)
                                      JOIN PROJ P USING(PN)   ORDER BY 1; -- WHERE D.DN != p.dn ORDER BY 1;
--
--  LISTAR PARTICIPACOES EM PROJ
--
SELECT * FROM PARTIC ORDER BY 1,2;
--
-- MOSTRAR INCOMPATIBILIDADES DN DO EMP <> DN DO PROJ EM Q PARTICIPA
--
-- AS PARTIC DEVE  SATISFAZER DN DO EN = DEPCRD DO PN
 
*/
--
-- ESCREVER AS PERGUNTAS DAS CONSULTAS ABAIXO
--
-- 1)
select e.enome from emp e where e.en not in (select en from partic); 

--2)
select e.*,pp.*,p.* 
    from     proj   p join partic as pp using(pn)
                       join emp as e using(en)
     where enome like "Joao"   order by sal desc  limit 3;
  
-- 3)
Select enome from emp where 
  exists(select * from depen where depen.en=emp.en and 
                                        depnome=emp.enome and
                                     (Case when depen.sexo='M' then 1 else 0 end)=emp.sexo);

-- 4)
Select en, partic.*  from partic where pn IN ('P1','P2'); 
--5)

Select enome from emp 
   where dN=(select dn from depto where dnome like 'ADM');

-- 6
Select sum(sal) as soma,max(sal) maior, min(sal) "menor sal",avg(sal) media_dos_salarios from emp
 where dN=(select dn from depto where dnome like 'ADM');

 -- 7)
 Select count(*) from emp where dN=(select dn from depto where dnome like 'ADM');

-- 8)
select distinct sal from emp;

--9 
Select x.enome from emp x
 where  (select count(*) from depen where en=x.en) >=1 







