PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;

DROP TABLE IF EXISTS  Emp; CREATE TABLE  Emp (En text primary key,  enome, tele, sal,
-- dN text references dept(Dn),  -- RECRIA EMP LA EMBAIXO
 sexo char,
 sup text references Emp(en)
);

DROP TABLE IF EXISTS depto; CREATE TABLE DEPTO (
       dn char(2) not null primary key,
       dnome char(12),
       teld char (11),
       chf char(3) REFERENCES EMP(EN)
     ON DELETE CASCADE on update cascade
);


INSERT INTO depto VALUES('D1','INFORMATICA','22945427','E06');
INSERT INTO depto VALUES('D2','ENG.CIVIL','23544987','E03');
INSERT INTO depto VALUES('D3','ENG.ELETRICA','23456543','E01');
INSERT INTO depto VALUES('D4','ENG.MECANICA','23544987','E10');
INSERT INTO depto VALUES('D5','ADM','33884989','E12');

DROP TABLE IF EXISTS proj; CREATE TABLE  proj (
       pn char(2) not null primary key,
       pnome char(8),
       orcamto integer,
       duracao integer  check (duracao<=orcamto),
       dn char(2) REFERENCES DEPTO(DN)
     ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO proj VALUES('P1','ALFA1',10000,10,'D2');
INSERT INTO proj VALUES('P2','BETA1',6000,6,'D3');
INSERT INTO proj VALUES('P3','GAMA1',2000,2,'D1');
INSERT INTO proj VALUES('P4','TETA',12000,12,'D1');
INSERT INTO proj VALUES('P5','EPSILON',6000,6,'D4');
INSERT INTO proj VALUES('P6','ALFA2',8000,8,'D4');
INSERT INTO proj VALUES('P7','BETA2',9000,9,'D5');
INSERT INTO proj VALUES('P8','GAMA2',10000,10,'D5');

DROP TABLE IF EXISTS  partic; CREATE TABLE  partic (
       en char(3) not null REFERENCES EMP(EN) ON DELETE CASCADE ON UPDATE CASCADE,
       pn char(2) not null REFERENCES DEPTO(DN) ON DELETE CASCADE ON UPDATE CASCADE,
       horas integer,
           primary key(en,pn)
);

INSERT INTO partic VALUES('E01','P1',3);
INSERT INTO partic VALUES('E01','P2',10);
INSERT INTO partic VALUES('E02','P3',5);
INSERT INTO partic VALUES('E04','P1',30);
INSERT INTO partic VALUES('E05','P2',15);
INSERT INTO partic VALUES('E05','P3',20);
INSERT INTO partic VALUES('E05','P7',50);
INSERT INTO partic VALUES('E06','P3',45);
INSERT INTO partic VALUES('E06','P4',10);
INSERT INTO partic VALUES('E07','P1',20);
INSERT INTO partic VALUES('E07','P4',10);
INSERT INTO partic VALUES('E09','P1',10);
INSERT INTO partic VALUES('E09','P4',20);
INSERT INTO partic VALUES('E10','P5',10);
INSERT INTO partic VALUES('E10','P6',45);
INSERT INTO partic VALUES('E','P1',60);
INSERT INTO partic VALUES('E','P5',10);
INSERT INTO partic VALUES('E13','P5',10);
INSERT INTO partic VALUES('E13','P7',10);
INSERT INTO partic VALUES('E13','P8',20);
INSERT INTO partic VALUES('E14','P1',20);
INSERT INTO partic VALUES('E14','P3',15);

DROP TABLE IF EXISTS Depen; CREATE TABLE  Depen( En text  references Emp(en), Depnome, sexo, dtnasc date,
  primary key(En , depnome)
 );

INSERT INTO Depen VALUES('E04','FRANCIS Filho','F','2007-11-30');
INSERT INTO Depen VALUES('E07','JOAO','M','2007-11-30');
INSERT INTO Depen VALUES('E08','MARCOS Filho','F','2007-11-30');
INSERT INTO Depen VALUES('E09','ANA Filho','M','2007-11-30');
INSERT INTO Depen VALUES('E11','ROSA Filho','M','2007-11-30');
INSERT INTO Depen VALUES('E16','BEATRIZ Filho','F','2007-11-30');

DROP TABLE IF EXISTS  Emp; CREATE TABLE  Emp (En text primary key,  enome, tele, sal,
 dn text references dept(Dn),
 sexo char,
 sup text references Emp(en)
);

INSERT INTO Emp VALUES('E01','JOAO','22945427',20000,'D3','1','E01');
INSERT INTO Emp VALUES('E02','PEDRO','23544987',10000,'D1','1','E02');
INSERT INTO Emp VALUES('E03','MARIA','22945427',30000,'D2','1','E03');
INSERT INTO Emp VALUES('E04','FRANCIS','23544987',5000,'D3','1','E04');
INSERT INTO Emp VALUES('E05','CARLA','33544989',8000,'D5','1','E05');
INSERT INTO Emp VALUES('E06','JOSE','33884989',20000,'D3','1','E06');
INSERT INTO Emp VALUES('E07','JOAO','23456543',15000,'D2','1','E07');
INSERT INTO Emp VALUES('E08','MARCOS','33884989',5000,'D5','1','E08');
INSERT INTO Emp VALUES('E09','ANA','23456543',5000,'D4','1','E09');
INSERT INTO Emp VALUES('E10','ELISA','33456544',30000,'D4','0','E10');
INSERT INTO Emp VALUES('E11','ROSA','33544989',15000,'D4','1','E11');
INSERT INTO Emp VALUES('E12','RICARDO','22945427',10000,'D5','1','E12');
INSERT INTO Emp VALUES('E13','ROBERTO','33544989',8000,'D5','1','E13');
INSERT INTO Emp VALUES('E14','BERNARDO','22945427',20000,'D2','1','E14');
INSERT INTO Emp VALUES('E15','BATISTA','33456544',20000,'D2','0','E15');
INSERT INTO Emp VALUES('E16','BEATRIZ','23456543',15000,'D1','1','E16');


COMMIT;
/* ACRESCENTAR OS TRIGGERS 

DROP TRIGGER IF EXISTS insertDEPTO; CREATE TRIGGER insertDEPTO AFTER INSERT ON        DEPTO
        FOR EACH ROW   BEGIN
  -- CHECA SE DN E CHF ESTAO OK
   UPDATE DEPTO SET DN=NEW.DN, CHF=NEW.CHF WHERE DN=NEW.DN;
  END
;
DROP TRIGGER IF EXISTS UPDTEdepto; CREATE TRIGGER UPDTEdepto AFTER UPDATE OF CHF ON    DEPTO
  FOR EACH ROW BEGIN
        SELECT CASE
                WHEN NEW.DN <> (SELECT DN FROM EMP WHERE EN = NEW.CHF)
                           THEN RAISE( ABORT, 'Um CHEFE DE DEPTO DEVE TRABALHAR NELE')
                WHEN (SELECT sal FROM EMP WHERE EN = NEW.CHF)<(select max(sal) from emp where dn=new.dn)
                           THEN RAISE( ABORT, 'Um CHEFE DE DEPTO DEVE ganhar o maior sal do depto')

         END;
  END;
*/