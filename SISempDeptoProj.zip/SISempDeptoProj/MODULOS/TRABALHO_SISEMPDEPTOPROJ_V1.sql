--*********************SisempDeptoProj***********************************
--**************************GRUPO1***************************************



-- 1) Obter os dados dos empregados que não tem (são) supervisor.

Select * from emp where sup=en;

-- 2) Obter os números e nomes dos Proj nos quais participe algum empregado cujo nome seja “JOAO”

select Pn,pnome from proj join partic using(pn) join emp using(en) where enome like 'Joao';

-- 3) Obter nome de cada um dos empregados que tenham algum dependente cujo nome e sexo 
-- sejam o mesmo do empregado em questão

Select enome from emp where
exists(select * from depen where depen.en=emp.en and
                                depnome=emp.enome and
                                (Case when depen.sexo='M’' then 1 else 0 end)=emp.sexo)

-- 4) Obter o numero e nome de cada um dos empregados que participam  em todos os projetos coordenados pelo departamento D1.

Select enome from emp e where exists
(select * from depen d where d.en=e.en and
depnome=enome and (Case when d.sexo='M' then 1 else 0 end)=e.sexo)

-- 5) Obter a matricula de “todos” os empregados que trabalham em um dos projetos P1,P2 ou P3.

Select en from partic where pn IN ('P1','P2','P3');

-- 6) Obter nome dos empregados que trabalham no departamento “ADM”.

Select enome from emp where dn=(select dn from depto where dnome like 'ADM');


-- 7) Obter a soma dos salários, o maior salário, o menor salário, e a média  salarial dos empregados.

Select sum(sal),max(sal), min(sal),avg(sal) from emp;

-- 8) Obter a soma dos salários, o maior salário, o menor salário, e a média  salarial dos empregados que trabalham no departamento “ADM”.

Select sum(sal),max(sal), min(sal),avg(sal) from emp  where dn=(select dn from depto where dnome like 'ADM');

-- 9) Obter o número total count (*) de empregados do departamento “ADM”.

Select count(*) from emp where dn=(select dn from depto where dnome like 'ADM');

-- 10) Obter o número dos diferentes valores de salário contido no banco de dados.

Select distinct sal from emp;

-- 11) Obter o nome todos os empregados que tem 2 ou mais dependentes.

Select x.enome from emp x where (select count(*) from depen where en=x.en) >=2

-- 12) Obter para cada departamento, seu número, quantidade de  empregados que trabalham nele e média de seus salários.

Select Emp.dn, count(enome) as qtd_funcionarios, avg(sal) as media_sal
From Emp
Left join DEPTO
On Emp.dn = DEPTO.dn
Group by Emp.dn

-- 13)  Obter para cada projeto em que trabalhem mais de dois empregados,  o número do projeto, seu nome e a quantidade de empregados que  participam dele.

Select partic.pn, count(en) as qtd_funcionarios, proj.pnome as nome_proj
From partic
Left join proj
On partic.pn = proj.pn
Group by partic.pn
Having qtd_funcionarios > 1

-- 14) para cada projeto , recupere seu nome, seu número e a  quantidde de empregados do departamento D5 que nele  trabalham.

select pn, pnome,  
   (select count(*) 
   from ( select * from partic join emp using (en) 
   where dn = "D5" and partic.pn = proj.pn ) ) 
as totalD5
from proj;

-- 15) para cada departamento o número total de empregados  cujos salários excedam 10000, mas somente para os  departamentos onde houver mais de 2 empregados.

Select dnome, count(enome) as qtd_funcionarios
From Emp
Left join DEPTO
On Emp.dn = DEPTO.dn
Where sal > 10000