/*----------------------------------------------------------------------------------- //
                     Lab:  SisHospital 
 
Um Hospital tem funcionarios (com RG, Nome, idade, cidade e Salario) Cada medico que trabalha no Hospital 
deve ser contratado como funcionario e é identificado pelo seu CRM. Um medico PODE TER  formacao em especialidades 
do Hospital que sao:(ortopedia, traumatologia,cardiologia e psiquiatria), mas so exerce uma delas no hospital. 
Para todo paciente internado no hospital com alguma doenca, são cadastrados alguns dados pessoais: RG, nome, 
 data do nascimento,endereco (cidade) e telefone(s) para contato. Um paciente (que pode ser funcionario) tem 
sempre um determinado medico como responsavel, com um horario de visita em certo dia da semana predeterminado. 
Pacientes estao sempre internados em enfermarias, que são identificadas por um numero, TEM certo numero de INTERNADOS e estao 
EM UM andar do Hospital. Medico tb pode ficar doente e ter consultas no hospital.
Restrição: Um medico que  ficar doente nao pode se consultar com ele mesmo.

O sistema deve permitir Consultas aos dados de Pacientes, Funcionarios, Medicos e 
 Consultas. Tambem deve permitir Transacoes de insercoes, exclusoes e atualizacoes. 
//------------------------------------------------------------------------------------//

Solucao: Criar hierarquias de classes de Entidades e usar Herança de Atributos

   PEssoa<--Funcionario<--Medico-->Consulta<--Paciente-->Enfermaria
         <--------------------------------------------------

 Obs. Datanasc e Tels do Paciente podem ser atributos de Pessoa, Idade pode ser derivada de Datanasc, 
      Especialidade eh atributo de Medico com valor em uma lista de valores possiveis
//------------------------------------------------------------------------------------

Tarefas do Lab  SisHospital
1) Criar uma pasta Lab  com APP e SisHospital
2) Tirar um Bkp do Hospital.db ==> Hospital.bkp na subpasta DADOS
3) Entrar no SqliteSpy que esta na pasta APP
4) Recriar o Hospital.db rodando o criahospital.sql que esta na subpasta MODULOS do SisHospital.
5) Analisar o Hospital.db na sub Pasta DADOS utilizando e  aumentando o modulo Consultas.sql que esta na pasta MODULOS 
6) Testar mudancas no Hospital.db para checar se os controles de integridade do bd estão funcionando.
7) Modificar o Hospital.db com um trigger que impeça a Restricao "Um medico nao pode se consultar com ele mesmo".
*/
--                ====== definicao e carga inicial do BD =======                        

Pragma foreign_keys=0; -- libera FKs
drop table if exists E;  -- Enfermaria 
drop table if exists PE; -- Pessoa
drop table if exists TelPe; -- telefones de Pessoa
drop table if exists F;  -- Funcionario sub Classe de PEssoa
drop table if exists M;  -- Medico  sub Classe de Funcionario
drop table if exists P;  -- Paciente sub Classe de PEssoa
drop table if exists C;  -- Consulta entre Medico e Paciente
--

Pragma foreign_keys=1; -- controla FKs
-- Enfermaria
create table  E(En integer primary key, andar int, Numint int default 0); -- num de internacoes comeca c zero
insert into E(En,andar)  values
(1,1),
(2,2),
(3,1)
;  


drop trigger if exists DelEnf;
CREATE TRIGGER Delenf before delete  on E begin
 select case when OLD.numint >0       
                        then Raise(abort,"Nao pode deletar Enf em uso")
        end;
end;

-- PEssoas

drop table if exists PE;
create table PE(RG integer primary key, nome text,
  datanasc date not null , -- se datanasc for dada derivar idade
  hoje   default (current_date) , 
  idade    as (hoje-datanasc),-- eh calculada se datanasc for dada
  cidade text
);
insert into PE(RG,nome,datanasc,cidade) values    -- hoje e idade sao definidas nos inserts de novas pessoas
(1,'JU','1980-03-31','BH'),
(2,'ZE','1990-03-31','BH'),
(3,'MA','1985-03-31','SP'),
(4,'RUI','1945-03-31','RJ'),
(5,'JO','1975-03-31','BH'),
(40,'RUI','1947-03-31','RJ'),
(50,'JO','1990-03-31','BH'),
(55,'LU','1985-03-31','RJ')
;
/*
-- derivar atributo Idade do atributo Datanasc
*/
-- Telefones das PEssoas
drop table if exists telPE;
create table telPE(RG integer references PE(RG) 
                      on delete cascade on update cascade, 
                   Tel numeric(10),
                   Primary key(RG,Tel)
);
insert into telPe values(1,2745544),(1,988997744),
 (4,977886655), (40,2345678),(40,2445566);    
 
 -- Funcionario eh PEssoa

drop table if exists F;
create table F(RG integer primary key references PE(RG)
                  on delete cascade on update cascade, 
               sal float
);
insert into F(RG,sal) values(1,2000.00);
insert into F(RG,sal) values(2,2000.00);
insert into F(RG,sal) values(3,3000.00);
insert into F(RG,sal) values(4,4000.00);
insert into F(RG,sal) values(5,2000.00);

-- Medico eh Funcionario

drop table if exists M;
create table M(CRM integer primary key,
               RG integer references F(RG)
                  on delete cascade on update cascade,  
               esp text check(esp in('ortopedia', 'traumatologia', 'cardiologia', 'psiquiatria'))
);
insert into M (CRM,RG,ESP) values
(100,4,'ortopedia'),
(200,2,'cardiologia'),
(300,3,'ortopedia')
;

-- Paciente eh PEssoa

drop table if exists P;
create table P(RG integer primary key references PE(RG)
                  on delete cascade on update cascade, 
               doenca text
);
insert into P values
(1,'GRIPE'),
(2,'TOSSE'),
(3,'FRATURA'),
(40,'GRIPE'),
(50,'ALERGIA'),
(55,'TOSSE')
;

-- Consulta 

drop table if exists C;
create table C(        -- marca os dias de sem e hora de consulta p um medico e paciente
 CRM integer references M 
     on delete cascade on update cascade,
 RG integer references P 
    on delete cascade on update cascade,
 diaSem text  check(diaSem in('domingo','segunda', 'terca', 'quarta', 'quinta','sexta','sabado')),
 hora time,
 primary key(crm,rg) 
);

drop trigger if exists InsMC;
CREATE TRIGGER InsMC after insert on C begin
  update C set rg=new.rg, crm=new.crm where rowid=new.rowid;
end;
drop trigger if exists UpdMC;
CREATE TRIGGER UpdMC after update on C begin
 select case when new.rg=(select RG from M where crm=New.crm)  -- esse rg eh o do medico
        then Raise(abort,"Med nao pode se consultar")
        end;
end;

insert into C (CRM , RG , diaSem , hora)  values
(100,1,'terca',time('12:00')),
(100,40,'segunda',time('10:30')),
(200,50,'quarta',time('15:00')),
(300,55,'segunda',time('10:00'))
;
--
-- views para facilitar as consultas 
-- criar views FPE, MFPE e PPE 
--
-- FPE Funcionario sub Classe de PEssoa
drop view if exists FPE; create view FPE as select * from F natural join PE;
-- MFPE Medico  sub Classe de Funcionario
drop view if exists MFPE; create view MFPE as select * from M natural join FPE ;
-- PPE Paciente sub Classe de PEssoa
drop view if exists PPE; create view PPE as select * from P natural join PE;

/*          ====== FIM  definicao e carga inicial do BD =======                       */
