-- ************************ SIS HOSPITAL **********************************
/* ************************************************************************
**************************************************************************/

-- *********************CONSULTAS AO BD*********************************** 

-- 1) Obter os nomes e RGs dos m�dicos e pacientes cadastrados no hospital

SELECT NOME,RG   FROM PE JOIN M USING(RG) UNION SELECT NOME,RG   FROM PE JOIN P USING(RG);

-- 2) Obter os nomes, RGs e idades dos m�dicos, pacientes e funcion�rios que residem em SP

select nome, idade, rg from pe where cidade like '%SP%';

-- 3) Obter os nomes e RGs dos funcion�rios que recebem sal�rios abaixo de R$ 3000,00 e que n�o est�o internados como Pacientes

select nome, rg from pe left join f using (rg) where sal < 3000 and rg not in (select rg from p);

-- 4) Obter os n�meros dos ambulat�rios onde nenhum m�dico d� atendimento

select * from E where en not in (select enf from p)  


-- 5) Obter os nomes e RGs dos funcion�rios que est�o internados como pacientes

select nome, rg from pe left join f using (rg) where rg in (select rg from p);


-- 6) Obter os nomes e RGs dos m�dicos que t�m consultas marcadas para 17/04/03 e est�o internados como pacientes

select pe.rg, pe.nome from m join c using (crm) join pe using(rg) where data = "2003-04-17"


-- 7) Obter o nome dos m�dicos que t�m consultas marcadas

select distinct nome from m left join c using (crm) join pe using(rg)


-- 8) Obter o n�mero e a capacidade dos ambulat�rios  do quinto andar e o nome dos m�dicos que atendem neles

select * from m join pe using(rg) join c using(crm) join p using (rg) where enf = (select en from e where andar = 5)


-- 9) Obter o n�mero dos ambulat�rios com capacidade superior � capacidade do ambulat�rio de n�mero 100

insert into E values
(100, 4, 22, 0);

select en from e where capacidade > (select capacidade from e where en = 100) 


-- 10) Obter o nome e o RG dos funcion�rios que recebem sal�rios iguais ou inferiores ao sal�rio da funcion�ria Ana (RG = 1001)

insert into pe values 
(1001, 'ANA', "1987-04-19", current_date, 35, 'RJ');

update pe set hoje = current_date;

insert into f values 
(1001, 3500.0);

select nome, rg from f join pe using (rg) where sal <= (select sal from f where rg = 1001) and rg <> 1001;


-- 11) Obter os nomes dos pacientes que s�o crian�as  (0-12 anos) e t�m consulta marcada ou com m�dico Jo�o Santos ou com a m�dica Maria Souza

insert into pe values 
(1002, 'JOAO SANTOS', "1980-03-31", CURRENT_DATE, 42, 'SP'),
(1003, 'MARIA SOUZA', "1980-03-31", CURRENT_DATE, 42, 'BH'); 

insert into pe values
(1004, 'RONALDO', "2021-03-31", CURRENT_DATE, 1, 'BH'),
(1005, 'DAVID', "2020-03-31", CURRENT_DATE, 2, 'SP');


INSERT INTO M VALUES 
(400, 1002, 'ortopedia'),
(500, 1003, 'ortopedia');

insert into C values 
(400, 1004, 'quinta', "12:00:00", "2022-03-19"),
(500, 1005, 'segunda', "12:05:00", "2022-03-19");

select pe.nome from pe join c using(rg) where idade < 12 and 
crm in (select crm from m join pe using(rg) where nome like '%joao santos%' or nome like '%maria souza%');


-- 12) Obter o n�mero e o andar dos ambulat�rios onde  nenhum m�dico d� atendimento

select en, andar from E where en not in (select enf from p) 


-- 13) Obter o nome e o RG dos pacientes que residem na mesma cidade do paciente Pedro Campos (RG = 1110)

insert into pe values
(1110, 'PEDRO CAMPOS', "1987-04-19", current_date, 35, 'BH');

insert into p values 
(1110, 'ALERGIA', 3);

insert into c values 
(400, 1110, 'quarta', "17:00:00", "2022-03-02");


select rg, nome from p join pe using(rg) where cidade = (select cidade from pe where rg = 1110) and nome <> 'PEDRO CAMPOS'


-- 14 ) Obter o c�digo (RG) dos pacientes que t�m consultas marcadas com todos os m�dicos

insert into c values 
(100, 1110, 'segunda', "14:38:02", "2022-12-09"),
(200, 1110, 'terca', "13:38:02", "2022-12-08"),
(300, 1110, 'quinta', "11:38:02", "2022-12-07"),
(500, 1110, 'sexta', "18:38:02", "2022-12-06");


select rg from pe
where not exists (
    select crm from m
    except
    select crm from c
    where c.rg = pe.rg

--15 ) Obter os dados de todos os m�dicos e, para aqueles que  t�m consultas marcadas, mostrar os dados de suas  consultas

select * from m 
left join c 
on m.crm = c.crm;

-- 16) Obter todos os m�dicos ortopedistas d�o atendimento no  mesmo ambulat�rio? Em caso afirmativo, buscar o  n�mero e o andar deste ambulat�rio

select e.en, e.andar
from e 
where not exists (
    select crm from m
    where m.esp like '%ortope%'
    except
    select crm from c
    join p on p.rg = c.rg
    where e.en = p.enf

-- 17) Obter o nome dos m�dicos que t�m consultas marcadas  com todos os pacientes

select m.crm, pe.nome from m join pe USING(rg)
where not exists (
    select rg from p
    except
    select rg from c
    where c.crm = m.crm

-- 18) Obter os n�meros de todos os ambulat�rios e, para  aqueles ambulat�rios nos quais m�dicos d�o  atendimento, exibir o CRM e o nome dos m�dicos  associados

Select En, nome, CRM
From E
Left join P
On E.En = P.ENF
Left join PE
On P.RG = PE.RG
Left join M
On P.RG = M.RG


-- 19) Obter o RG e nome de todos os pacientes e de todos os  m�dicos, apresentando estes dados de forma  relacionada para aqueles que possuem consultas  marcadas 

SELECT M.rg, M.nome, PE.rg, PE.nome FROM MFPE M JOIN C ON M.CRM=C.CRM JOIN PE ON C.RG=PE.RG;


--********************ATUALIZA��ES NO BD***************************************


-- 1) Remover os ambulat�rios onde nenhum m�dico d�  atendimento

DELETE FROM E WHERE Numint=0;

-- 2) Inserir � funcion�rio Jo�o da Silva (RG = 1000) foi  internado como paciente. Ele est� com hepatite�.

INSERT INTO P VALUES (1000, 'HEPATITE', 1);

-- 3) Atualize o BD com �a m�dica Maria (CRM = 37)  transferiu todas as suas consultas do dia 29/04/03  para o dia 08/05/03

-- Inserir a m�dica Maria como Pessoa na table PE:

Insert into PE values
(6, 'Maria', "1988-06-11", current_date, 'SP');

-- Inserir a m�dica Maria na table M (M�dico):

Insert into M values
(37, 6, 'psiquiatria');

-- Inserir uma pessoa (Joaquim) na table PE (Pessoa):

Insert into PE values
(80, 'Joaquim', "1946-07-02", current_date, 'SP');

-- Inserir uma segunda pessoa (Gilda) na table PE (Pessoa):

Insert into PE values
(81, 'Gilda', "1958-11-07", current_date, 'SP');

-- Inserir Joaquim na table P (Paciente):

Insert into P values
(80, 'depressao', "3");

-- Inserir Gilda na table P (Paciente):

Insert into P values
(81, 'depressao', "3");

-- Inserir Joaquim se consultando no dia 29/04/03 (ter�a-feira) com m�dica Maria na table C (Consulta):

Insert into C values
(37, 80, 'terca', "07:30:00");

-- Inserir Gilda se consultando no dia 29/04/03 (ter�a-feira) com m�dica Maria na table C (Consulta):

Insert into C values
(37, 81, 'terca', "10:00:00");

-- Verificando na table C se as consultas dos pacientes P Joaquim e Gilda est�o para ter�a-feira, com a m�dica M do CRM = 37:

Select CRM, RG, diaSem
From C
Where CRM = 37

-- Atualizando a nova data de consulta dos pacientes P Joaquim e Gilda, na table C, de ter�a-feira (29/04/03) para o quinta-feira (08/05/03):

Update C 
Set diaSem = 'quinta'
Where CRM = 37

-- Consultando novamente por meio do c�digo abaixo, temos a nova data de consulta dos pacientes P Joaquim e Gilda, na table C, pela m�dica do CRM = 37, de ter�a-feira (29/04/03) para o quinta-feira (08/05/03):

Select *
From C
