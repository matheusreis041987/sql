
/*-----------------------------------------------------------*/
/*                consultas no bd Hospital                   */
/*-----------------------------------------------------------*/
pragma foreign_keys=1;
/*
Obter os nomes e RGs dos médicos e pacientes cadastrados no hospital
SELECT NOME,RG   FROM PE JOIN M USING(RG) UNION SELECT NOME,RG   FROM PE JOIN P USING(RG)

Obter os nomes, RGs e idades dos médicos, pacientes e funcionários (PE?) que residem em SP
SELECT NOME,RG,IDADE, CIDADE  FROM PE WHERE CIDADE LIKE 'sp'

Obter os nomes e RGs dos funcionários que recebem salários abaixo de R$ 3000,00 e que não estão internados como Pacientes
SELECT PE.NOME,PE.RG FROM F JOIN PE USING(RG)WHERE SAL<3000 AND F.RG NOT IN (SELECT RG FROM P)
SELECT PE.NOME,PE.RG FROM F JOIN PE USING(RG) WHERE SAL<3000 AND RG NOT IN (SELECT RG FROM P)

Obter os númerose e num de internados dos ENFERMARIA E OS CRM DOS médicos que dao atendimento la
SELECT EN,NUMINT,CRM FROM E JOIN P ON ENF=EN JOIN C ON P.RG=C.RG

-- ====== USANDO AS VIEWS =======

Obter os CRM,nomes e RGs dos médicos (que estão internados como pacientes)
SELECT  CRM,NOME, RG from MFPE WHERE RG IN (SELECT RG FROM P);
OU
SELECT M.crm,PE.NOME,PE.RG from PE JOIN M USING(RG) WHERE M.RG IN (SELECT RG FROM P);

Obter os nomes e RGs dos funcionários que estão internados como pacientes
SELECT  NOME, RG from FPE WHERE RG IN (SELECT RG FROM P);

Nome e CRM dos Medicos q dao consultas as segundas E PARA QUE PACIENTE
SELECT
  (select NOME from MFPE M WHERE C.CRM=M.CRM)    NOMMED,
C.*,
  (SELECT NOME FROM PE JOIN P ON PE.RG=P.RG WHERE C.RG=P.RG)  NOMPAC
 FROM C WHERE DIASEM LIKE 'SEGUNDA';
-- ================================================================
-- PEssoas
-- deletar uma pessoa => tira tudo dele se  ele for paciente, Medico etc (sua consulta e tels)
-- ================================================================
-- Funcionarios

   select *  from FPE;
-- funcionarios c/ telefones
   select *  from FPE left  join telPE using(RG);

-- ================================================================
-- Pacientes
   select rg,nome from PPE ;

-- pacientes c/ telefones
   select * from PPE left  join telPE using(RG);

-- Pacientes q sao funcionarios
   select rg,nome from PPE  INTERSECT  select rg,nome from FPE;

-- Pacientes q NAo sao funcionarios
   select * from PPE   where rg not in(select rg from FPE);
--ou
   select rg,nome from PPE  EXCEPT  select rg,nome from FPE;

-- Pacientes que nao estao sendo mais cuidados (em C)
   select * from P where RG not in  (select RG from C); 

-- Pacientes q nao sao Medicos
   select nome,rg from PPE EXCEPT select nome,rg from MFPE; 

-- deletar um paciente (mantem PE)(so deve sair a consulta dele)

-- ================================================================  
-- Medicos  (sao subclass de f)
   select * from MFPE;  

-- Medicos q sao pacientes 
   select rg,nome  from MFPE  INTERSECT select rg,nome from PPE; 
-- ou
   select rg,nome from MFPE  where rg in(select rg from PPE);

-- Medicos dando Consultas 
 select medico.nome as med,c.*,paciente.nome as pac from
      MFPE medico left join c                on medico.crm=c.crm   
                  left join PPE as paciente  on c.rg=paciente.rg  -- pq nao using(rg)?
  order by 1;
-- ou 
 select  medico.nome as med,
         c.*,
         paciente.nome as pac  
   from MFPE as medico,
             c,
             PPE as paciente    -- c,m,FPE as fpe,PPE as ppe 
   where  medico.crm=c.crm and c.rg=paciente.rg  
  order by 1;
-- ou
  select
   (select nome from MFPE  where crm=c.crm) as med,
   c.*,
   (select nome from PPE where rg=c.rg) as pac
  from c  order by 1;

-- Medico q cuidando/cuidou de si mesmo
  select 
   (select nome from MFPE where crm=c.crm) as nomeM,
   C.*,
   (select nome from PPE where rg=c.rg) as nomeP 
   from c where rg=(select rg from MFPE where crm=c.crm); 

-- Medicos q deram consultas desde  um mes atras -- o inicio do mes
  Select (select nome from MFPE where crm=c.crm) as nomeM,* from C
   where data between date('now','-1 month') and date('now') ; 

