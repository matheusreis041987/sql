--
-- ATUALIZACOES NO BD     
--
-- Pacientes nao sendo atendidos
select * from P where rg not in(select Rg from c);

-- deletar  Pacientes nao sendo atendidos
delete from P where rg not in(select Rg from c);



-- cadastrar  uma nova PEssoa chamada 'ZEZE' nascida em '1980-06-31' EM 'BE'
-- Internar agora essa PEssoa   como Paciente com 'gripe' na enfermaria 2
BEGIN TRANSACTION;   
insert into PE(nome,datanasc,cidade) values('ZEZE','1980-06-31','BE'); -- AS OUTRAS COLS SAO GERADAS 
insert into P values((select Rg from PE where rowid=Last_insert_rowid()), 'Gripe', 2);
-- cadastrar a consulta COM UM MEDICO QUE ATENDA NA SEGUNDA
insert into C values((select crm from C where  DIASEM LIKE 'SEGUNDA' limit 1),
                     (select Rg from PE where rowid=Last_insert_rowid()),'segunda',time('now','localtime') );
--  baixar 1 da capacidade da enf dele
update E set capacidade =capacidade-1 where En=2;
END TRANSACTION;

-- insert into ppe values(57,'Febre','Pedro',null,50,'RJ');  -- nao aceita pq PPE eh view

insert into PE values(null,'Pedro',null,50,'RJ'); -- erro ha col  generated

select Rg,date('now'),time('now','localtime'),rowid,Last_insert_rowid() from PE ;
-- ================================================================  

-- inserir medico Rui Rg=4 (buscar seu crm 100)em consultas  (100,4, hoje as 12h).  e ele mesmo se Consultando
insert into C values (100,4,'terca',time('12:00')) -- da erro "medico nao pode se consultar"

-- Enfermarias do 2o andar
 select * from E  where andar=2;  


 --   ================================================
