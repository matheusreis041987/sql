Pragma foreign_key = 0; -- liberar FKs
drop table if exists E; -- Enfermaria
drop table if exists PE; -- Pessoa
drop table if exists TelPe; -- Telefone Pessoa
drop table if exists F; -- Funcion�rio subclasse Pessoa
drop table if exists M; -- M�dico subclasse de Pessoa
drop table if exists P;  -- Paciente subclasse de pessoa
drop table if exists C; -- Consulta entre M�dico e Paciente

pragma foreign_key = 1;

create table E (En integer primary key, andar int, capacidade int, Numint default 0); -- numero de internados come�a com zero
insert into E(En, andar, capacidade) values
(1,1, 30),
(2,2, 20),
(3,1, 25);

drop trigger if exists Delenf;
create trigger Delenf before delete on E begin
select case when old.Numint > 0 
                   then Raise(abort, "N�o pode deletar Enf em uso")
                   end;
end;

drop trigger if exists CapEnf;
create trigger CapEnf before update on E begin
select case when new.Numint > new.capacidade 
                   then Raise(abort, "N�o pode colocar mais paciente que a capacidade da enfemaria")
                   end;
end;

-- delete from e where En = 3;

drop table if exists PE;
create table PE (RG integer primary key, nome text,
datanasc date not null, -- se a datanasc for dada derivar a idade
hoje default (current_date),
idade date,  -- as (hoje-datanasc) n�o funcionou
cidade text
);

insert into PE (RG, nome, datanasc, cidade)  values
(1, 'JU', '1980-03-31', 'BH'),
(2, 'ZE', '1990-03-31', 'BH'),
(3, 'MA', '1985-03-31', 'SP'),
(4, 'RUI', '1945-03-31', 'RJ'),
(5, 'JO', '1975-03-31', 'BH'),
(40, 'RUI', '1947-03-31', 'RJ'),
(50, 'JO', '1990-03-31', 'BH'),
(55, 'LU', '1985-03-31', 'RJ')
;

UPDATE pe set idade = hoje-datanasc;