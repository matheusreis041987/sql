-- pacientes que s�o funcion�ios

/* -----------------------------------------------------------*/
/*                Consultas no BD Hospital                    */
/* -----------------------------------------------------------*/
pragma foreign_keys = 1;
-- ===============================================================
-- Pessoas
-- deletar uma pessoa => tirar tudo dele se ele for paciente, m�dico etc (sua consulta e tels)
-- ================================================================
-- fucion�rios

select * from fpe;
-- funcion�rios com telefone
select * from fpe left join telPE using(RG);
select *, group_concat(tel, ' , ') as telefones from fpe  left join telPE using(rg) ;
-- ================================================================
-- Pacientes

select rg, nome from ppe;
-- pacientes que s�o funcionario
select rg, nome from ppe intersect select rg,nome from fpe;

-- pacientes que n�o sao funcionario

select rg, nome from ppe except  select rg,nome from fpe;
-- ou
select rg, nome from ppe where rg not in (select rg from f);

-- pacientes que n�o est�o sendo mais cuidados
select * from p where rg not in (select rg from c);

select rg, nome from ppe  where rg not in (select rg from c);

-- Paciente que n�o s�o m�dicos

select rg, nome from ppe where rg not in (select rg from m);
-- ou
select rg, nome from ppe except select rg, nome from mfpe;

-- m�dicos que n�o est�o consultando

select crm, rg from m where crm not in (select crm from c) ;

-- m�dicos que s�o pacientes

select crm, rg from m where rg in (select rg from c);

-- m�dicos dando consulta

select c.crm, c.rg, m.esp from c join m using(crm) order by crm asc;
-- ou
select  c.crm as CRM , c.rg as RG , m.esp as ESPEC,mfpe.nome as NOME  from c join (m, mfpe) 
where c.crm = m.crm and m.rg = mfpe.rg order by crm desc;

-- medicos cuidando de si;

select * from c where rg in (select rg from m);

-- enfermarias que tem gripe como doen�a

select rg, doenca, p.enf, andar from p join E where p.enf = e.en and doenca like '%gripe%';

-- incluir coluna em enfermaria e data em consulta


alter table p add column enf integer references E(en);

update P set enf = 1;
update P set enf = 2 where rg in (2,40,50);
update P set enf = 3 where rg in (55);

alter table C add column data date;
update C set data = date('2022-09-11');
update C set data = date('2022-05-30') where rg in (1, 50);
update C set data = date('2022-07-18') where rg in (40); 

