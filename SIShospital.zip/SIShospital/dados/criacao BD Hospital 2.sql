Pragma foreign_key = 0; -- liberar FKs
drop table if exists E; -- Enfermaria
drop table if exists PE; -- Pessoa
drop table if exists TelPE; -- Telefone Pessoa
drop table if exists F; -- Funcion�rio subclasse Pessoa
drop table if exists M; -- M�dico subclasse de Pessoa
drop table if exists P;  -- Paciente subclasse de pessoa
drop table if exists C; -- Consulta entre M�dico e Paciente

pragma foreign_key = 1;

create table E (En integer primary key, andar int, capacidade int, Numint default 0); -- numero de internados come�a com zero
insert into E(En, andar, capacidade) values
(1,1, 30),
(2,2, 20),
(3,1, 25);

drop trigger if exists Delenf;
create trigger Delenf before delete on E begin
select case when old.Numint > 0 
                   then Raise(abort, "N�o pode deletar Enf em uso")
                   end;
end;

drop trigger if exists CapEnf;
create trigger CapEnf before update on E begin
select case when new.Numint > new.capacidade 
                   then Raise(abort, "N�o pode colocar mais paciente que a capacidade da enfemaria")
                   end;
end;

-- delete from e where En = 3;

drop table if exists PE;
create table PE (RG integer primary key, nome text,
datanasc date not null, -- se a datanasc for dada derivar a idade * melhorar a forma de calcular
hoje default (current_date),
idade date,  -- as (hoje-datanasc) n�o funcionou
cidade text
);

insert into PE (RG, nome, datanasc, cidade)  values
(1, 'JU', '1980-03-31', 'BH'),
(2, 'ZE', '1990-03-31', 'BH'),
(3, 'MA', '1985-03-31', 'SP'),
(4, 'RUI', '1945-03-31', 'RJ'),
(5, 'JO', '1975-03-31', 'BH'),
(40, 'RUI', '1947-03-31', 'RJ'),
(50, 'JO', '1990-03-31', 'BH'),
(55, 'LU', '1985-03-31', 'RJ')
;

UPDATE pe set idade = hoje-datanasc;

drop table if exists telPE;
create table telPE (RG integer references PE(RG)
                   on delete cascade on update cascade,
                   Tel numeric (10),
                   Primary key (RG, Tel)
);

insert into TelPE values (1, 2745544), (1, 988997744),
(4,977886655), (40, 2545678), (40, 2445566);


drop table if exists F;
create table F (RG integer primary key references PE(RG)
                on delete cascade on update cascade,
                sal float 
);  

insert into F values 
(1, 2000.00),
(2, 2000.00),
(3, 3000.00),
(4, 4000.00),
(5, 2000.00);


drop table if exists M;
create table M (CRM integer primary key,
                RG integer references F(RG)
                on delete cascade on update cascade,
                esp text check(esp in ('ortopedia', 'traumatologia', 'cardiologia', 'psiquiatria'))
);

insert into M (CRM, RG, esp) values 
(100, 4, 'ortopedia'),
(200, 2, 'cardiologia'),
(300, 3, 'ortopedia');


drop table if exists P;
create table P (RG integer primary key references PE(RG)
                on delete cascade on update cascade,
                doenca text
);

insert into P values 
(1, 'GRIPE'),
(2, 'TOSSE'),
(3, 'FRATURA'),
(40, 'GRIPE'),
(50, 'ALERGIA'),
(55, 'TOSSE');

drop table if exists C;
create table C (
CRM integer references M(CRM)
on delete cascade on update cascade,
RG integer references P (RG)
on delete cascade on update cascade,
diaSem text check (diaSem in ('domingo', 'segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado')),
hora time,
primary key (CRM, RG)
);

drop trigger if exists InsMC;
create trigger InsMC after insert on C begin
update C set rg=new.rg, crm=new.crm where rowid=new.rowid;
end;

drop trigger if exists UpdMC;
create trigger UpdMC after update on C begin
select case when new.rg = (select RG from M where crm=New.CRM)
then raise (abort, "M�dico n�o pode se consultar")
end;
end;

insert into C (CRM, RG, diaSem, hora) values
(100, 1, 'terca', time('12:00')),
(100, 40, 'segunda', time('10:30')),
(200, 50, 'quarta', time('15:00')),
(300, 55, 'segunda', time('10:00'));


create view FPE as select * from F natural join PE;
create view MFPE as select * from M natural join FPE;
create view PPE as select * from P natural join PE;
                   